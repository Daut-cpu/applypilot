import { type Page } from "@playwright/test";
import {
  test,
  expect,
  selectOrCreate,
  uniqueName,
  type CleanupRegistry,
} from "./fixtures";

async function createResume(
  page: Page,
  title: string,
  cleanup: CleanupRegistry,
) {
  await page.getByRole("button", { name: "New", exact: true }).click();
  await page.getByRole("menuitem", { name: "Add New Resume" }).click();
  await page.getByPlaceholder("Ex: Full Stack Developer").fill(title);
  await page.getByRole("button", { name: "Save" }).click();
  cleanup.resume(title);
}

test.describe("Profile page", () => {
  test("should create a new resume", async ({ page, cleanup }) => {
    const resumeTitle = uniqueName("Test Resume");
    await page.getByRole("link", { name: "Profile" }).click();
    await createResume(page, resumeTitle, cleanup);
    // Reload-after-create/delete is a client fetch; under parallel e2e load
    // the dev server can take longer than the default 10s to reflect it.
    await expect(page.locator("tbody")).toContainText(resumeTitle, {
      timeout: 20000,
    });
    await deleteResume(page, resumeTitle);
    // Assert on the persistent outcome (row removed) rather than the toast,
    // which auto-dismisses after 5s and can vanish before the poll under load.
    await expect(page.locator("tbody")).not.toContainText(resumeTitle, {
      timeout: 20000,
    });
  });

  test("should edit the resume title", async ({ page, baseURL, cleanup }) => {
    const resumeTitle = uniqueName("Test Resume");
    const editedTitle = uniqueName("Test Resume edited");
    // Register the edited title too, since it's what the row becomes on success.
    cleanup.resume(editedTitle);
    await page.getByRole("link", { name: "Profile" }).click();
    await expect(page).toHaveURL(baseURL + "/dashboard/profile");
    await createResume(page, resumeTitle, cleanup);

    const cells = page.getByText(new RegExp(resumeTitle, "i"));
    await expect(cells.first()).toBeVisible();
    await page
      .getByRole("row", { name: resumeTitle })
      .getByTestId("document-actions-menu-btn")
      .first()
      .click();
    await page.getByRole("menuitem", { name: /Edit Resume Title/ }).click();
    await page.getByPlaceholder("Ex: Full Stack Developer").fill(editedTitle);
    await page.getByRole("dialog").getByRole("button", { name: "Save" }).click();
    await expect(page.locator("tbody")).toContainText(editedTitle);
  });

  test("should add resume contact info", async ({ page, cleanup }) => {
    const resumeTitle = uniqueName("Test Resume");
    await page.getByRole("link", { name: "Profile" }).click();
    await createResume(page, resumeTitle, cleanup);
    await addContactInfo(page, resumeTitle, "John", "Doe");
    // Same reload-under-load headroom as the create/delete assertions above.
    await expect(
      page.getByRole("heading", { name: "John Doe" }),
    ).toBeVisible({ timeout: 20000 });
  });

  test("should edit resume contact info", async ({ page, cleanup }) => {
    const resumeTitle = uniqueName("Test Resume");
    await page.getByRole("link", { name: "Profile" }).click();
    await createResume(page, resumeTitle, cleanup);
    await addContactInfo(page, resumeTitle, "John", "Doe");
    await expect(
      page.getByRole("heading", { name: "John Doe" }),
    ).toBeVisible({ timeout: 20000 });
    await page.getByRole("button", { name: "Edit" }).click();
    await expect(
      page.getByRole("heading", { name: "Edit Contact Info" }),
    ).toBeVisible();
    await page.getByLabel("First Name").fill("Jane");
    await page.getByRole("button", { name: "Save" }).click();
    await expect(page.getByRole("heading", { name: "Jane Doe" })).toBeVisible();
  });

  test("should add resume summary section", async ({ page, cleanup }) => {
    const resumeTitle = uniqueName("Test Resume");
    await page.getByRole("link", { name: "Profile" }).click();
    await createResume(page, resumeTitle, cleanup);
    await addSummary(page, resumeTitle, "this is test summary");
    await expect(page.getByRole("heading", { name: "Summary" })).toBeVisible();
    await expect(page.getByText("this is test summary")).toBeVisible();
  });

  test("should edit resume summary section", async ({ page, cleanup }) => {
    const resumeTitle = uniqueName("Test Resume");
    await page.getByRole("link", { name: "Profile" }).click();
    await createResume(page, resumeTitle, cleanup);
    await addSummary(page, resumeTitle, "this is test summary");
    await expect(page.getByText("this is test summary")).toBeVisible();
    await page.getByRole("button", { name: "Edit" }).click();
    await expect(
      page.getByRole("heading", { name: "Edit Summary" }),
    ).toBeVisible();
    await page
      .getByRole("dialog")
      .locator(".tiptap")
      .fill("this is updated summary\n");
    await page.getByRole("button", { name: "Save" }).click();
    await expect(page.getByText("this is updated summary")).toBeVisible();
    await expect(page.getByText("this is test summary")).not.toBeVisible();
  });

  test("should add resume work experience section", async ({
    page,
    cleanup,
  }) => {
    const resumeTitle = uniqueName("Test Resume");
    const jobText = uniqueName("Software Developer");
    await page.getByRole("link", { name: "Profile" }).click();
    await createResume(page, resumeTitle, cleanup);
    await addExperience(page, resumeTitle, jobText, cleanup);
    await expect(
      page.getByRole("heading", { name: jobText }).first(),
    ).toBeVisible();
  });

  test("should add resume work experience after clicking Edit Experience section", async ({
    page,
    cleanup,
  }) => {
    const resumeTitle = uniqueName("Test Resume");
    const jobText = uniqueName("Software Developer");
    await page.getByRole("link", { name: "Profile" }).click();
    await createResume(page, resumeTitle, cleanup);
    await addExperience(page, resumeTitle, jobText, cleanup);
    await expect(
      page.getByRole("heading", { name: jobText }).first(),
    ).toBeVisible();
    await page
      .getByText(jobText + "Edit")
      .getByRole("button", { name: "Edit" })
      .click();
    await expect(
      page.getByRole("heading", { name: "Edit Experience" }),
    ).toBeVisible();
    await page.getByText("Cancel").click();
    await page.getByRole("button", { name: "Add Section" }).click();
    await page.getByRole("menuitem", { name: "Add Experience" }).click();
    await expect(
      page.getByRole("heading", { name: "Add Experience" }),
    ).toBeVisible();
    await page.getByText("Cancel").click();
  });

  test("should add resume education section", async ({ page, cleanup }) => {
    const resumeTitle = uniqueName("Test Resume");
    const schoolText = uniqueName("test school");
    await page.getByRole("link", { name: "Profile" }).click();
    await createResume(page, resumeTitle, cleanup);
    await addEducation(page, resumeTitle, schoolText, cleanup);
    await expect(
      page.getByRole("heading", { name: schoolText }).first(),
    ).toBeVisible();
  });

  test("should edit resume education section", async ({ page, cleanup }) => {
    const resumeTitle = uniqueName("Test Resume");
    const schoolText = uniqueName("test school");
    const editedSchoolText = uniqueName("edited school");
    await page.getByRole("link", { name: "Profile" }).click();
    await createResume(page, resumeTitle, cleanup);
    await addEducation(page, resumeTitle, schoolText, cleanup);
    await expect(
      page.getByRole("heading", { name: schoolText }).first(),
    ).toBeVisible();
    await page.getByRole("button", { name: "Edit" }).click();
    await expect(
      page.getByRole("heading", { name: "Edit Education" }),
    ).toBeVisible();
    await page.getByPlaceholder("Ex: Stanford").fill(editedSchoolText);
    await page.getByRole("button", { name: "Save" }).click();
    await expect(
      page.getByRole("heading", { name: editedSchoolText }).first(),
    ).toBeVisible();
  });

  test("should add resume skills section", async ({ page, cleanup }) => {
    const resumeTitle = uniqueName("Test Resume");
    const skillText = uniqueName("Skill Test");
    await page.getByRole("link", { name: "Profile" }).click();
    await createResume(page, resumeTitle, cleanup);
    await addSkill(page, resumeTitle, skillText, cleanup);
    await expect(
      page.getByRole("heading", { name: "Core Skills" }),
    ).toBeVisible();
    await expect(page.getByText(skillText, { exact: true })).toBeVisible();
  });

  test("should delete resume skills section", async ({ page, cleanup }) => {
    const resumeTitle = uniqueName("Test Resume");
    const skillText = uniqueName("Skill Test");
    await page.getByRole("link", { name: "Profile" }).click();
    await createResume(page, resumeTitle, cleanup);
    await addSkill(page, resumeTitle, skillText, cleanup);
    await expect(page.getByText(skillText, { exact: true })).toBeVisible();
    await page.getByRole("button", { name: "Delete" }).click();
    await expect(page.getByRole("alertdialog")).toContainText(
      "Delete skills section?",
    );
    await page
      .getByRole("alertdialog")
      .getByRole("button", { name: "Delete" })
      .click();
    await expect(page.getByText(skillText, { exact: true })).not.toBeVisible();
  });

  test("should add resume certification section", async ({
    page,
    cleanup,
  }) => {
    const resumeTitle = uniqueName("Test Resume");
    const certTitle = uniqueName("AWS Certified Solutions Architect");
    await page.getByRole("link", { name: "Profile" }).click();
    await createResume(page, resumeTitle, cleanup);
    await addCertification(page, resumeTitle, certTitle, cleanup);
    await expect(
      page.getByRole("heading", { name: certTitle }).first(),
    ).toBeVisible();
    await expect(page.getByText("Amazon Web Services")).toBeVisible();
  });

  test("should edit resume certification", async ({ page, cleanup }) => {
    const resumeTitle = uniqueName("Test Resume");
    const certTitle = uniqueName("AWS Certified Solutions Architect");
    const editedOrg = uniqueName("Edited Org");
    await page.getByRole("link", { name: "Profile" }).click();
    await createResume(page, resumeTitle, cleanup);
    await addCertification(page, resumeTitle, certTitle, cleanup);
    await expect(
      page.getByRole("heading", { name: certTitle }).first(),
    ).toBeVisible();
    await page.getByRole("button", { name: "Edit" }).click();
    await expect(
      page.getByRole("heading", { name: "Edit Certification / License" }),
    ).toBeVisible();
    await page.getByLabel("Issuing Organization").fill(editedOrg);
    await page.getByRole("button", { name: "Save" }).click();
    await expect(page.getByText(editedOrg)).toBeVisible();
  });
});

async function addContactInfo(
  page: Page,
  resumeTitle: string,
  firstName: string,
  lastName: string,
) {
  await page
    .getByRole("row", { name: new RegExp(resumeTitle, "i") })
    .first()
    .getByTestId("document-actions-menu-btn")
    .click();
  await page.getByRole("link", { name: "View/Edit Resume" }).click();
  await page.getByRole("button", { name: "Add Section" }).click();
  await page.getByRole("menuitem", { name: "Add Contact Info" }).click();
  await page.getByLabel("First Name").waitFor({ state: "visible" });
  await page.getByLabel("First Name").click();
  await page.getByLabel("First Name").fill(firstName);
  await page.getByLabel("Last Name").click();
  await page.getByLabel("Last Name").fill(lastName);
  await page.getByLabel("Headline").click();
  await page
    .getByLabel("Headline")
    .fill("Skill developer with testing skills");
  await page.getByLabel("Email").click();
  await page.getByLabel("Email").fill("admin@example.com");
  await page.getByLabel("Phone").click();
  await page.getByLabel("Phone").fill("123456789");
  await page.getByLabel("Address").click();
  await page.getByLabel("Address").fill("Calgary");
  await page.getByRole("button", { name: "Save" }).click();
}

async function addSummary(page: Page, resumeTitle: string, summaryText: string) {
  await page
    .getByRole("row", { name: new RegExp(resumeTitle, "i") })
    .first()
    .getByTestId("document-actions-menu-btn")
    .click();
  await page.getByRole("link", { name: "View/Edit Resume" }).click();
  await expect(page.getByRole("heading", { name: "Resume" })).toBeVisible();
  await page.getByRole("button", { name: "Add Section" }).click();
  await page.getByRole("menuitem", { name: "Add Summary" }).click();
  await page.getByLabel("Section Title").fill("Summary");
  await page.locator(".tiptap").click();
  await page.locator(".tiptap").fill(summaryText + "\n");
  await page.getByRole("button", { name: "Save" }).click();
}

async function addEducation(
  page: Page,
  resumeTitle: string,
  schoolText: string,
  cleanup: CleanupRegistry,
) {
  const locationText = uniqueName("location test");
  await page
    .getByRole("row", { name: new RegExp(resumeTitle, "i") })
    .first()
    .getByTestId("document-actions-menu-btn")
    .click({ force: true });
  await page.getByRole("link", { name: "View/Edit Resume" }).click();
  await expect(page.getByRole("heading", { name: "Resume" })).toBeVisible();
  await page.getByRole("button", { name: "Add Section" }).click();
  await page.getByRole("menuitem", { name: "Add Education" }).click();
  // Wait for the dialog to open
  await page.waitForTimeout(500);
  // Only fill section title if it's visible (when creating new section)
  const sectionTitleField = page.getByPlaceholder("Ex: Education");
  if (await sectionTitleField.isVisible()) {
    await sectionTitleField.fill("Education");
  }
  await page.getByPlaceholder("Ex: Stanford").click();
  await page.getByPlaceholder("Ex: Stanford").fill(schoolText);
  await selectOrCreate(
    page,
    "Location",
    "Create or Search location",
    locationText,
  );
  cleanup.location(locationText);
  await page.getByPlaceholder("Ex: Bachelor's").click();
  await page.getByPlaceholder("Ex: Bachelor's").fill("degree text");
  await page.getByPlaceholder("Ex: Computer Science").click();
  await page.getByPlaceholder("Ex: Computer Science").fill("computer science");
  await page.getByLabel("Start Date").click();
  // Wait for calendar popover to open
  await page.waitForTimeout(1000);
  // Click on any available date in the calendar
  const startDateCell = page.getByRole("gridcell", { name: "15" }).first();
  await startDateCell.waitFor({ state: "visible", timeout: 5000 });
  await startDateCell.click();
  await page.getByLabel("End Date").click();
  // Wait for calendar popover to open
  await page.waitForTimeout(1000);
  // Click on any available date in the calendar
  const endDateCell = page.getByRole("gridcell", { name: "20" }).first();
  await endDateCell.waitFor({ state: "visible", timeout: 5000 });
  await endDateCell.click();
  await page.locator("div:nth-child(2) > .tiptap").click();
  await page.locator("div:nth-child(2) > .tiptap").fill("test description");
  await page.getByRole("button", { name: "Save" }).click();
}

async function addExperience(
  page: Page,
  resumeTitle: string,
  jobText: string,
  cleanup: CleanupRegistry,
) {
  const companyText = uniqueName("company test");
  const locationText = uniqueName("location test");
  await page
    .getByRole("row", { name: new RegExp(resumeTitle, "i") })
    .first()
    .getByTestId("document-actions-menu-btn")
    .click();
  await page.getByRole("link", { name: "View/Edit Resume" }).click();
  await expect(page.getByRole("heading", { name: "Resume" })).toBeVisible();
  await page.getByRole("button", { name: "Add Section" }).click();
  await page.getByRole("menuitem", { name: "Add Experience" }).click();
  // Wait for the dialog to open
  await page.waitForTimeout(500);
  // Only fill section title if it's visible (when creating new section)
  const sectionTitleField = page.getByPlaceholder("Ex: Experience");
  if (await sectionTitleField.isVisible()) {
    await sectionTitleField.fill("Experience");
    await sectionTitleField.press("Tab");
  }
  await selectOrCreate(page, "Job Title", "Create or Search title", jobText);
  cleanup.title(jobText);
  await selectOrCreate(page, "Company", "Create or Search company", companyText);
  cleanup.company(companyText);
  await selectOrCreate(
    page,
    "Job Location",
    "Create or Search location",
    locationText,
  );
  cleanup.location(locationText);
  await page.getByLabel("Start Date").click();
  // Wait for calendar popover to open
  await page.waitForTimeout(1000);
  // Click on any available date in the calendar
  const dateCell = page.getByRole("gridcell", { name: "15" }).first();
  await dateCell.waitFor({ state: "visible", timeout: 5000 });
  await dateCell.click();
  await page.locator("div:nth-child(2) > .tiptap").click();
  await page.locator("div:nth-child(2) > .tiptap").fill("test description");
  await page.getByRole("button", { name: "Save" }).click();
}

async function addSkill(
  page: Page,
  resumeTitle: string,
  skillText: string,
  cleanup: CleanupRegistry,
) {
  await page
    .getByRole("row", { name: new RegExp(resumeTitle, "i") })
    .first()
    .getByTestId("document-actions-menu-btn")
    .click();
  await page.getByRole("link", { name: "View/Edit Resume" }).click();
  await expect(page.getByRole("heading", { name: "Resume" })).toBeVisible();
  await page.getByRole("button", { name: "Add Section" }).click();
  await page.getByRole("menuitem", { name: "Add Skills" }).click();
  await page.getByRole("combobox", { name: "Search or add a skill…" }).click();
  await page.getByPlaceholder("Type a skill...").fill(skillText);
  await page.getByText(`Create "${skillText}"`).click();
  cleanup.tag(skillText);
  await expect(page.getByText(skillText, { exact: true })).toBeVisible();
  await page.getByRole("button", { name: "Save" }).click();
}

async function addCertification(
  page: Page,
  resumeTitle: string,
  certTitle: string,
  cleanup: CleanupRegistry,
) {
  await page
    .getByRole("row", { name: new RegExp(resumeTitle, "i") })
    .first()
    .getByTestId("document-actions-menu-btn")
    .click();
  await page.getByRole("link", { name: "View/Edit Resume" }).click();
  await expect(page.getByRole("heading", { name: "Resume" })).toBeVisible();
  await page.getByRole("button", { name: "Add Section" }).click();
  await page
    .getByRole("menuitem", { name: "Add Certification / License" })
    .click();
  // Wait for the dialog to open
  await page.waitForTimeout(500);
  // Only fill section title if it's visible (when creating new section)
  const sectionTitleField = page.getByPlaceholder("Ex: Certifications");
  if (await sectionTitleField.isVisible()) {
    await sectionTitleField.fill("Certifications");
  }
  await page.getByLabel("Certification / License Name").fill(certTitle);
  await page.getByLabel("Issuing Organization").fill("Amazon Web Services");
  await page.getByLabel("Issue Date").click();
  // Wait for calendar popover to open
  await page.waitForTimeout(1000);
  const issueDateCell = page.getByRole("gridcell", { name: "10" }).first();
  await issueDateCell.waitFor({ state: "visible", timeout: 5000 });
  await issueDateCell.click();
  await page.getByRole("button", { name: "Save" }).click();
}

async function deleteResume(page: Page, title: string) {
  await page.getByRole("link", { name: "Profile" }).click();
  await page.waitForLoadState("networkidle");
  const row = page.getByRole("row", { name: new RegExp(title, "i") }).first();
  await row.waitFor({ state: "visible", timeout: 10000 });
  await row.getByTestId("document-actions-menu-btn").click({ force: true });
  await page.getByRole("menuitem", { name: "Delete" }).click({ force: true });
  await expect(page.getByRole("alertdialog")).toContainText(
    "Are you sure you want to delete this resume?",
  );
  await page.getByRole("button", { name: "Delete" }).click({ force: true });
}
